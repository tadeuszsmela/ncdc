
Install_script_1.sql file contains commands that create the database objects listed in points 1-2 of the task.

Install_script_2.sql file contains commands that create the database objects listed point 4 of the task.

Mydata.csv file is a file with sample data for import.
